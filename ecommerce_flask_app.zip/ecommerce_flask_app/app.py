"""
E-Commerce Web Application using Python (Flask)
-------------------------------------------------
Features:
- User registration & login (secure password hashing)
- Role-based access control (customer / admin)
- Product browsing with search
- Cart management (add/remove/update quantity)
- Order placement & order history
- Admin dashboard for managing products, users, and orders
- SQLite database with SQLAlchemy ORM (CRUD operations)

Run:
    pip install -r requirements.txt
    python app.py
Then open http://127.0.0.1:5000
Default admin login: admin@shop.com / admin123 (auto-created on first run)
"""

from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'change-this-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///store.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ---------------------------------------------------------------------------
# MODELS
# ---------------------------------------------------------------------------

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default='customer')  # 'customer' or 'admin'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, default=0)
    image_url = db.Column(db.String(300), default='https://via.placeholder.com/250')


class CartItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)

    product = db.relationship('Product')


class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='Placed')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    items = db.relationship('OrderItem', backref='order', cascade='all, delete-orphan')
    user = db.relationship('User')


class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)  # price at time of purchase

    product = db.relationship('Product')


# ---------------------------------------------------------------------------
# HELPERS / DECORATORS
# ---------------------------------------------------------------------------

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return wrapper


def current_user():
    if 'user_id' in session:
        return User.query.get(session['user_id'])
    return None


@app.context_processor
def inject_user():
    return dict(current_user=current_user())


# ---------------------------------------------------------------------------
# PUBLIC ROUTES
# ---------------------------------------------------------------------------

@app.route('/')
def index():
    query = request.args.get('q', '')
    if query:
        products = Product.query.filter(Product.name.ilike(f'%{query}%')).all()
    else:
        products = Product.query.all()
    return render_template('index.html', products=products, query=query)


@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    return render_template('product_detail.html', product=product)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'danger')
            return redirect(url_for('register'))

        user = User(name=name, email=email, role='customer')
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            session['user_id'] = user.id
            session['role'] = user.role
            session['name'] = user.name
            flash(f'Welcome back, {user.name}!', 'success')
            return redirect(url_for('admin_dashboard') if user.role == 'admin' else url_for('index'))
        flash('Invalid email or password.', 'danger')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))


# ---------------------------------------------------------------------------
# CART ROUTES
# ---------------------------------------------------------------------------

@app.route('/cart')
@login_required
def cart():
    items = CartItem.query.filter_by(user_id=session['user_id']).all()
    total = sum(item.product.price * item.quantity for item in items)
    return render_template('cart.html', items=items, total=total)


@app.route('/cart/add/<int:product_id>', methods=['POST'])
@login_required
def add_to_cart(product_id):
    product = Product.query.get_or_404(product_id)
    qty = int(request.form.get('quantity', 1))

    existing = CartItem.query.filter_by(user_id=session['user_id'], product_id=product_id).first()
    if existing:
        existing.quantity += qty
    else:
        db.session.add(CartItem(user_id=session['user_id'], product_id=product_id, quantity=qty))
    db.session.commit()
    flash(f'{product.name} added to cart.', 'success')
    return redirect(url_for('cart'))


@app.route('/cart/update/<int:item_id>', methods=['POST'])
@login_required
def update_cart(item_id):
    item = CartItem.query.get_or_404(item_id)
    if item.user_id != session['user_id']:
        flash('Not authorized.', 'danger')
        return redirect(url_for('cart'))
    qty = int(request.form.get('quantity', 1))
    if qty <= 0:
        db.session.delete(item)
    else:
        item.quantity = qty
    db.session.commit()
    return redirect(url_for('cart'))


@app.route('/cart/remove/<int:item_id>')
@login_required
def remove_from_cart(item_id):
    item = CartItem.query.get_or_404(item_id)
    if item.user_id == session['user_id']:
        db.session.delete(item)
        db.session.commit()
    return redirect(url_for('cart'))


@app.route('/checkout', methods=['POST'])
@login_required
def checkout():
    items = CartItem.query.filter_by(user_id=session['user_id']).all()
    if not items:
        flash('Your cart is empty.', 'warning')
        return redirect(url_for('cart'))

    total = sum(item.product.price * item.quantity for item in items)
    order = Order(user_id=session['user_id'], total_amount=total, status='Placed')
    db.session.add(order)
    db.session.flush()  # get order.id before commit

    for item in items:
        if item.product.stock < item.quantity:
            flash(f'Insufficient stock for {item.product.name}.', 'danger')
            db.session.rollback()
            return redirect(url_for('cart'))
        db.session.add(OrderItem(
            order_id=order.id,
            product_id=item.product_id,
            quantity=item.quantity,
            price=item.product.price
        ))
        item.product.stock -= item.quantity
        db.session.delete(item)

    db.session.commit()
    flash('Order placed successfully!', 'success')
    return redirect(url_for('orders'))


@app.route('/orders')
@login_required
def orders():
    user_orders = Order.query.filter_by(user_id=session['user_id']).order_by(Order.created_at.desc()).all()
    return render_template('orders.html', orders=user_orders)


# ---------------------------------------------------------------------------
# ADMIN ROUTES (product / user / order management)
# ---------------------------------------------------------------------------

@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    products = Product.query.all()
    users = User.query.all()
    all_orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('admin_dashboard.html', products=products, users=users, orders=all_orders)


@app.route('/admin/product/add', methods=['POST'])
@login_required
@admin_required
def admin_add_product():
    product = Product(
        name=request.form['name'],
        description=request.form.get('description', ''),
        price=float(request.form['price']),
        stock=int(request.form['stock']),
        image_url=request.form.get('image_url') or 'https://via.placeholder.com/250'
    )
    db.session.add(product)
    db.session.commit()
    flash('Product added.', 'success')
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/product/edit/<int:product_id>', methods=['POST'])
@login_required
@admin_required
def admin_edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    product.name = request.form['name']
    product.description = request.form.get('description', '')
    product.price = float(request.form['price'])
    product.stock = int(request.form['stock'])
    db.session.commit()
    flash('Product updated.', 'success')
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/product/delete/<int:product_id>')
@login_required
@admin_required
def admin_delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    flash('Product deleted.', 'info')
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/order/status/<int:order_id>', methods=['POST'])
@login_required
@admin_required
def admin_update_order_status(order_id):
    order = Order.query.get_or_404(order_id)
    order.status = request.form['status']
    db.session.commit()
    flash('Order status updated.', 'success')
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/user/delete/<int:user_id>')
@login_required
@admin_required
def admin_delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.role != 'admin':
        db.session.delete(user)
        db.session.commit()
        flash('User removed.', 'info')
    return redirect(url_for('admin_dashboard'))


# ---------------------------------------------------------------------------
# DB INIT + SEED DATA
# ---------------------------------------------------------------------------

def seed_data():
    if not User.query.filter_by(email='admin@shop.com').first():
        admin = User(name='Admin', email='admin@shop.com', role='admin')
        admin.set_password('admin123')
        db.session.add(admin)

    if Product.query.count() == 0:
        sample_products = [
            Product(name='Wireless Headphones', description='Noise-cancelling over-ear headphones.',
                     price=59.99, stock=25, image_url='https://via.placeholder.com/250?text=Headphones'),
            Product(name='Smart Watch', description='Fitness tracking smart watch.',
                     price=89.99, stock=15, image_url='https://via.placeholder.com/250?text=Smart+Watch'),
            Product(name='Backpack', description='Water-resistant laptop backpack.',
                     price=34.99, stock=40, image_url='https://via.placeholder.com/250?text=Backpack'),
            Product(name='Mechanical Keyboard', description='RGB mechanical keyboard.',
                     price=49.99, stock=20, image_url='https://via.placeholder.com/250?text=Keyboard'),
        ]
        db.session.bulk_save_objects(sample_products)

    db.session.commit()


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        seed_data()
    app.run(debug=True)
